<?php
include 'Telegram.php';
$telegram = new Telegram('622305637:AAGY0GjNTTSyD16DD6e6rcn2yBzQBKlWtig');

var_dump($telegram->getData());
