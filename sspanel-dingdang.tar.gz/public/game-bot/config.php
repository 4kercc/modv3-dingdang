<?php
$config = [
		'database_type' => "mysql", //连接类型：mysql、mssql、sybase  
		'database_name' => "sspanel", //数据库名  
		'server' => "localhost", //数据库地址   
		'port' => 3306,
		'username' => "sspanel", //数据库账号  
		'password' => "zmn5M22fpJMKC3zB", //数据库密码 
		'charset' => 'utf8'
];
$bot_token = '622305637:AAGY0GjNTTSyD16DD6e6rcn2yBzQBKlWtig';
?>